package org.bonitasoft.camel.bonita.api;

public class LoginAPI {
	

}
